from .auth_routes import auth_routes
from .resume_routes import resume_routes
