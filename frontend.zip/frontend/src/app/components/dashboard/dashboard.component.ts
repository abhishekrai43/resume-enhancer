import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';



@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  imports: [CommonModule]
})

export class DashboardComponent {
  selectedFile: File | null = null;
  uploadStatus = '';
  processedResumeUrl = '';
  apiUrl = 'http://localhost:5001/resume/upload'; 

  constructor(private http: HttpClient) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
    this.uploadStatus = '';
  }

  uploadResume() {
    if (!this.selectedFile) {
      alert('Please select a resume file to upload.');
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post(this.apiUrl, formData).subscribe(
      (response: any) => {
        console.log('✅ Resume uploaded:', response);
        this.uploadStatus = 'Resume uploaded successfully!';
        this.processedResumeUrl = response.processed_resume_url; // Assuming API returns a URL
      },
      (error) => {
        console.error('❌ Upload failed', error);
        this.uploadStatus = 'Failed to upload resume. Try again.';
      }
    );
  }
}
