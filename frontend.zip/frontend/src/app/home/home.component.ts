import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from '../components/register/register.component'; // ✅ Import RegisterComponent


@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  imports: [CommonModule, FormsModule, RouterModule, HttpClientModule, RegisterComponent]
})
export class HomeComponent {
  showRegisterModal = false;
  registerComponent: any = null;
  loginData = { email: '', password: '' }; 
  apiUrl = 'http://localhost:5001/auth/login'; 

  constructor(private router: Router, private http: HttpClient) {}

  async toggleRegisterModal() {
    this.showRegisterModal = !this.showRegisterModal;
    console.log(`Register Modal ${this.showRegisterModal ? "Opened" : "Closed"}`);

    if (!this.registerComponent) {
      try {
        const module = await import('../components/register/register.component');
        this.registerComponent = module.RegisterComponent;
      } catch (error) {
        console.error("Error loading RegisterComponent", error);
      }
    }
  }

  onLogin() {
    console.log("✅ Attempting Login...", this.loginData);

    if (!this.loginData.email || !this.loginData.password) {
      alert("Email and Password are required!");
      return;
    }

    this.http.post(this.apiUrl, this.loginData).subscribe(
      (response: any) => {
        console.log("✅ Login Successful", response);
        alert("Login successful!");
        localStorage.setItem("access_token", response.access_token);
        this.router.navigate(['/dashboard']); // ✅ Redirect to dashboard
      },
      (error) => {
        console.error("❌ Login Failed", error);
        alert("Invalid email or password. Please try again.");
      }
    );
  }

  onRegisterSuccess() {
    this.showRegisterModal = false; 
  }
}
